﻿namespace Session_5___AsyncSql___UI.Views
{
    partial class FormUpdatePerson
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtUpdateFirstName = new TextBox();
            txtUpdateLastName = new TextBox();
            label6 = new Label();
            txtUpdateAddress = new TextBox();
            label2 = new Label();
            txtUpdateCity = new TextBox();
            label3 = new Label();
            txtUpdatePostalCode = new TextBox();
            label4 = new Label();
            txtUpdateEmail = new TextBox();
            label5 = new Label();
            txtUpdatePhone = new TextBox();
            label7 = new Label();
            btnSave = new Button();
            panel1 = new Panel();
            panel2 = new Panel();
            label0 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(79, 63);
            label1.Name = "label1";
            label1.Size = new Size(62, 15);
            label1.TabIndex = 0;
            label1.Text = "Firstname:";
            // 
            // txtUpdateFirstName
            // 
            txtUpdateFirstName.BorderStyle = BorderStyle.FixedSingle;
            txtUpdateFirstName.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtUpdateFirstName.Location = new Point(80, 81);
            txtUpdateFirstName.Name = "txtUpdateFirstName";
            txtUpdateFirstName.Size = new Size(261, 23);
            txtUpdateFirstName.TabIndex = 1;
            // 
            // txtUpdateLastName
            // 
            txtUpdateLastName.BorderStyle = BorderStyle.FixedSingle;
            txtUpdateLastName.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtUpdateLastName.Location = new Point(80, 143);
            txtUpdateLastName.Name = "txtUpdateLastName";
            txtUpdateLastName.Size = new Size(261, 23);
            txtUpdateLastName.TabIndex = 2;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(80, 125);
            label6.Name = "label6";
            label6.Size = new Size(61, 15);
            label6.TabIndex = 10;
            label6.Text = "Lastname:";
            // 
            // txtUpdateAddress
            // 
            txtUpdateAddress.BorderStyle = BorderStyle.FixedSingle;
            txtUpdateAddress.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtUpdateAddress.Location = new Point(80, 205);
            txtUpdateAddress.Name = "txtUpdateAddress";
            txtUpdateAddress.Size = new Size(261, 23);
            txtUpdateAddress.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(80, 187);
            label2.Name = "label2";
            label2.Size = new Size(52, 15);
            label2.TabIndex = 12;
            label2.Text = "Address:";
            // 
            // txtUpdateCity
            // 
            txtUpdateCity.BorderStyle = BorderStyle.FixedSingle;
            txtUpdateCity.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtUpdateCity.Location = new Point(80, 267);
            txtUpdateCity.Name = "txtUpdateCity";
            txtUpdateCity.Size = new Size(261, 23);
            txtUpdateCity.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(80, 249);
            label3.Name = "label3";
            label3.Size = new Size(31, 15);
            label3.TabIndex = 14;
            label3.Text = "City:";
            // 
            // txtUpdatePostalCode
            // 
            txtUpdatePostalCode.BorderStyle = BorderStyle.FixedSingle;
            txtUpdatePostalCode.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtUpdatePostalCode.Location = new Point(80, 329);
            txtUpdatePostalCode.Name = "txtUpdatePostalCode";
            txtUpdatePostalCode.Size = new Size(261, 23);
            txtUpdatePostalCode.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(79, 311);
            label4.Name = "label4";
            label4.Size = new Size(68, 15);
            label4.TabIndex = 16;
            label4.Text = "Postalcode:";
            // 
            // txtUpdateEmail
            // 
            txtUpdateEmail.BorderStyle = BorderStyle.FixedSingle;
            txtUpdateEmail.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtUpdateEmail.Location = new Point(80, 391);
            txtUpdateEmail.Name = "txtUpdateEmail";
            txtUpdateEmail.Size = new Size(261, 23);
            txtUpdateEmail.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(79, 373);
            label5.Name = "label5";
            label5.Size = new Size(39, 15);
            label5.TabIndex = 18;
            label5.Text = "Email:";
            // 
            // txtUpdatePhone
            // 
            txtUpdatePhone.BorderStyle = BorderStyle.FixedSingle;
            txtUpdatePhone.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtUpdatePhone.Location = new Point(80, 453);
            txtUpdatePhone.Name = "txtUpdatePhone";
            txtUpdatePhone.Size = new Size(261, 23);
            txtUpdatePhone.TabIndex = 7;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(79, 435);
            label7.Name = "label7";
            label7.Size = new Size(44, 15);
            label7.TabIndex = 20;
            label7.Text = "Phone:";
            // 
            // btnSave
            // 
            btnSave.BackColor = Color.FromArgb(160, 113, 255);
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnSave.ForeColor = Color.White;
            btnSave.Location = new Point(80, 501);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(86, 29);
            btnSave.TabIndex = 22;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = false;
            btnSave.Click += btnSave_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(txtUpdateFirstName);
            panel1.Controls.Add(btnSave);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(txtUpdatePhone);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(txtUpdateLastName);
            panel1.Controls.Add(txtUpdateEmail);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(txtUpdateAddress);
            panel1.Controls.Add(txtUpdatePostalCode);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(txtUpdateCity);
            panel1.Font = new Font("Sans Serif Collection", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel1.Location = new Point(57, 184);
            panel1.Name = "panel1";
            panel1.Size = new Size(423, 592);
            panel1.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(160, 113, 255);
            panel2.Controls.Add(label0);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(537, 140);
            panel2.TabIndex = 24;
            // 
            // label0
            // 
            label0.AutoSize = true;
            label0.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label0.ForeColor = Color.White;
            label0.Location = new Point(31, 55);
            label0.Name = "label0";
            label0.Size = new Size(111, 21);
            label0.TabIndex = 0;
            label0.Text = "Update Person";
            // 
            // FormUpdatePerson
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(537, 812);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "FormUpdatePerson";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormUpdatePerson";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private TextBox txtUpdateFirstName;
        private TextBox txtUpdateLastName;
        private Label label6;
        private TextBox txtUpdateAddress;
        private Label label2;
        private TextBox txtUpdateCity;
        private Label label3;
        private TextBox txtUpdatePostalCode;
        private Label label4;
        private TextBox txtUpdateEmail;
        private Label label5;
        private TextBox txtUpdatePhone;
        private Label label7;
        private Button btnSave;
        private Panel panel1;
        private Panel panel2;
        private Label label0;
    }
}